# Short Answer Feedback v2.0

This version of SAF contains additional English questions and responses collected in later semesters. Feedback was provided by tutors during the semester instead of annotated after the fact. Additionally, some styling tags missed in the initial preparation of the dataset  and empty responses were removed.
